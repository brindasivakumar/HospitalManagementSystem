
package com.management;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.Properties;

public class DBConnectionManager {


    public static Connection getConnection() throws SQLException, ClassNotFoundException,IOException {
        Properties properties = new Properties();
        Connection connection = null;
        try {           
        	FileInputStream fis=new FileInputStream("database.properties");
            properties.load(fis);
            String driver = properties.getProperty("db.driver");
            String url = properties.getProperty("db.url");
            String username = properties.getProperty("db.username");
            String password = properties.getProperty("db.password");
            Class.forName(driver);
            connection = DriverManager.getConnection(url, username, password);
        }catch (FileNotFoundException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} catch (IOException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();  

       
    } return connection;
}}