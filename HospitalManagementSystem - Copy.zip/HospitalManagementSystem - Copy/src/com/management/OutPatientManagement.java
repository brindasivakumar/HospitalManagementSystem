
package com.management;


import java.sql.*;
import java.util.*;
import com.model.OutPatient;
import java.io.IOException;

public class OutPatientManagement {

    public void insertOutPatientList(List<OutPatient> outPatients) throws SQLException, IOException, ClassNotFoundException {
        String patientQuery = "INSERT INTO patient (PATIENT_ID, PATIENT_NAME, PHONE_NUMBER, AGE, GENDER, MEDICAL_HISTORY, PREFFERED_SPECIALIST, MEDICINE_FEE, PATIENT_TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String outPatientQuery = "INSERT INTO outpatient (PATIENT_ID, REGISTRATION_FEES) VALUES (?, ?)";

        try (Connection conn = DBConnectionManager.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps1 = conn.prepareStatement(patientQuery);
                 PreparedStatement ps2 = conn.prepareStatement(outPatientQuery)) {

                for (OutPatient i : outPatients) {
                    ps1.setString(1, i.getPatientId());
                    ps1.setString(2, i.getPatientName());
                    ps1.setLong(3, i.getPhoneNumber());
                    ps1.setInt(4, i.getAge());
                    ps1.setString(5, i.getGender());
                    ps1.setString(6, i.getMedicalHistory());
                    ps1.setString(7, i.getPrefferedSpecialist());
                    ps1.setDouble(8,i.getMedicineFee());
                    ps1.setString(9, i.getPatientType());
                    ps1.addBatch();

                    ps2.setString(1, i.getPatientId());
                    ps2.setDouble(2,i.getRegistrationFee());
                    ps2.addBatch();
                }
                ps1.executeBatch();
                ps2.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }
    public int getMaxOutPatientIdNumber() throws SQLException, IOException, ClassNotFoundException {
        int max = 0;
        String query = "SELECT MAX(CAST(SUBSTRING(PATIENT_ID, 5) AS UNSIGNED)) AS max_id FROM outpatient";

        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next() && rs.getString("max_id") != null) {
                max = Integer.parseInt(rs.getString("max_id"));
            }
        }
        return max;
    }

    public boolean checkIdExists(String id) throws SQLException, IOException, ClassNotFoundException {
        String query = "SELECT PATIENT_ID FROM outpatient WHERE PATIENT_ID = ?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }

    public void updateOutPatientPhoneNumber(String id, long newPhone) throws SQLException, IOException, ClassNotFoundException {
        String query = "UPDATE patient SET PHONE_NUMBER = ? WHERE PATIENT_ID = ?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setLong(1, newPhone);
            ps.setString(2, id);
            ps.executeUpdate();
        }
    }

    public OutPatient retrieveOutPatientList(String id) throws SQLException, IOException, ClassNotFoundException {
        String query = "SELECT p.*, o.REGISTRATION_FEES FROM patient p JOIN outpatient o ON p.PATIENT_ID = o.PATIENT_ID WHERE p.PATIENT_ID = ?";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
            	
                return new OutPatient(
                        rs.getString("PATIENT_ID"),
                        rs.getString("PATIENT_NAME"),
                        rs.getLong("PHONE_NUMBER"),
                        rs.getInt("AGE"),
                        rs.getString("GENDER"),
                        rs.getString("MEDICAL_HISTORY"),
                        rs.getString("PREFFERED_SPECIALIST"),
                        rs.getDouble("MEDICINE_FEE"),
                        rs.getString("PATIENT_TYPE"),
                        rs.getDouble("REGISTRATION_FEES")
                );
            } else {
                return null;
            }
        }
    }

    public void deleteOutpatientDetailsFromDB(String id) throws SQLException, IOException, ClassNotFoundException {
        String deleteOutpatient = "DELETE FROM outpatient WHERE PATIENT_ID = ?";
        String deletePatient = "DELETE FROM patient WHERE PATIENT_ID = ?";

        try (Connection conn = DBConnectionManager.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement psOut = conn.prepareStatement(deleteOutpatient);
                 PreparedStatement psPat = conn.prepareStatement(deletePatient)) {
                psOut.setString(1, id);
                psOut.executeUpdate();

                psPat.setString(1, id);
                psPat.executeUpdate();

                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }
}
