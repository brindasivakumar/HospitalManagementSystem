package com.management;

import com.model.Doctor;

import java.sql.*;
import java.sql.Date;
import java.util.List;
import java.io.IOException;

public class DoctorManagement {
	  public int getMaxDoctorIdNumber() throws SQLException, IOException, ClassNotFoundException {
	        int max = 0;
	        String query = "SELECT MAX(CAST(SUBSTRING(DOCTOR_ID, 4) AS UNSIGNED)) AS max_id FROM doctor";

	        try (Connection conn = DBConnectionManager.getConnection();
	             PreparedStatement ps = conn.prepareStatement(query);
	             ResultSet rs = ps.executeQuery()) {
	            if (rs.next() && rs.getString("max_id") != null) {
	                max = Integer.parseInt(rs.getString("max_id"));
	            }
	        }
	        return max;
	    }

    public void insertDoctorList(List<Doctor> doctors) throws SQLException, IOException, ClassNotFoundException {
        String query = "INSERT INTO doctor (DOCTOR_ID, DOCTOR_NAME, DOCTOR_FEE, SPECIALIZATION, AVAILABLE_DATE, AVAILABLE_TIME) VALUES (?, ?, ?, ?, ?, ?)";
        

        try (Connection conn = DBConnectionManager.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                for (Doctor d : doctors) {
                    ps.setString(1, d.getDoctorId());
                    ps.setString(2, d.getDoctorName());
                    ps.setDouble(3, d.getDoctorFees());
                    ps.setString(4, d.getSpecialization());
                    ps.setDate(5,(Date) d.getAvailableDate());
                    ps.setTime(6, d.getAvailableTime());
                    ps.addBatch();
                }
                ps.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public void updateDoctorFee(String doctorId, double newFee) 
            throws SQLException, IOException, ClassNotFoundException {
        String query = "UPDATE doctor SET DOCTOR_FEE = ? WHERE DOCTOR_ID = ?";

        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setDouble(1, newFee);
            ps.setString(2, doctorId);
            ps.executeUpdate();
        }
    }

    public void updateDoctorAvailableDate(String doctorId, Date newDate) 
            throws SQLException, IOException, ClassNotFoundException {
        String query = "UPDATE doctor SET AVAILABLE_DATE = ? WHERE DOCTOR_ID = ?";

        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setDate(1, newDate);
            ps.setString(2, doctorId);
            ps.executeUpdate();
        }
    }  


    public Doctor retrieveDoctorDetails(String doctorId) 
            throws SQLException, IOException, ClassNotFoundException {
        String query = "SELECT DOCTOR_ID,  DOCTOR_NAME,  DOCTOR_FEE, SPECIALIZATION, AVAILABLE_DATE, AVAILABLE_TIME " +
                       "FROM doctor WHERE DOCTOR_ID = ?";

        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, doctorId);
           ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new Doctor(
                        rs.getString("DOCTOR_ID"),
                        rs.getString("DOCTOR_NAME"),
                        rs.getDouble("DOCTOR_FEE"),
                        rs.getString("SPECIALIZATION"),
                        rs.getDate("AVAILABLE_DATE"),
                        rs.getTime("AVAILABLE_TIME")
                    );
                }
            
        }
        return null;
    }

}