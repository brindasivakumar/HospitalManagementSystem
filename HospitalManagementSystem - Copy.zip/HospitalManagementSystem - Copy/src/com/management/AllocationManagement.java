package com.management;

import java.sql.*;
import java.sql.Date;
import java.util.*;
import com.model.Allocation;
import java.io.IOException;
public class AllocationManagement {

	public int getMaxAllocationIdNumber() throws SQLException, IOException, ClassNotFoundException  {
		// TODO Auto-generated method stub
		   int max = 0;
	        String query = "SELECT MAX(CAST(SUBSTRING(ALLOCATION_ID, 4) AS UNSIGNED)) AS max_id FROM allocation";

	        try (Connection conn = DBConnectionManager.getConnection();
	             PreparedStatement ps = conn.prepareStatement(query);
	             ResultSet rs = ps.executeQuery()) {
	            if (rs.next() && rs.getString("max_id") != null) {
	                max = Integer.parseInt(rs.getString("max_id"));
	            }
	        }
	        return max;	
	}		
	  
	public String getInPatientId(String name, long phone)  throws SQLException, IOException, ClassNotFoundException{
		// TODO Auto-generated method stub
		  String query = "SELECT PATIENT_ID FROM patient WHERE PATIENT_NAME = ? AND PHONE_NUMBER = ?";
		    try (Connection conn = DBConnectionManager.getConnection();
		         PreparedStatement ps = conn.prepareStatement(query)) {
		        ps.setString(1, name);
		        ps.setLong(2, phone);
		        ResultSet rs = ps.executeQuery();
		        if (rs.next()) {
		            return rs.getString("PATIENT_ID");
		        } else {
		            return null; // no such patient
		        }
		    }
		}

	public boolean checkIdExists(String id)throws SQLException, IOException, ClassNotFoundException {
		
		// TODO Auto-generated method stub
		 String query = "SELECT PATIENT_ID FROM allocation WHERE PATIENT_ID = ?";
	        try (Connection conn = DBConnectionManager.getConnection();
	             PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setString(1, id);
	            ResultSet rs = ps.executeQuery();
	            return rs.next();
	        }
	
	}

	public void insertAllocationList(List<Allocation> allocation) throws SQLException, IOException, ClassNotFoundException {
        String query = "INSERT INTO allocation (Allocation_ID, Patient_ID,room_number,no_of_days_admitted,admission_date,discharge_date,treatment,room_type,want_food) VALUES (?, ?, ?, ?, ?, ?,?,?,?)";
        

        try (Connection conn = DBConnectionManager.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                for (Allocation a : allocation) {
                    ps.setString(1, a.getAllocationId());
                    ps.setString(2, a.getPatientId());
                    ps.setInt(3, a.getRoomNumber());
                    ps.setInt(4, a.getNoOfdaysAdmitted());
                    ps.setDate(5, (Date)a.getAdmissionDate());
                    ps.setDate(6,(Date) a.getDischargeDate());
                    ps.setString(7, a.getTreatment());
                    ps.setString(8, a.getRoomType());
                    ps.setString(9, a.getWantFood());
                    ps.addBatch();
                                 }
                ps.executeBatch();
                conn.commit();
            } catch (SQLException e) {
            	System.out.println(e.getMessage());
                conn.rollback();
                throw e;
            }
        }

	}



    public Allocation retrieveAllocationDetails(String id) 
            throws SQLException, IOException, ClassNotFoundException {
        String query = "SELECT Allocation_ID, patient_ID,room_number,no_of_days_admitted,admission_date,discharge_date,treatment,room_type,want_food	" +
                       "FROM allocation WHERE allocation_ID = ?";

        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, id);
           ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new Allocation(
                    rs.getString("Allocation_Id"),
                    rs.getString("Patient_Id"),
                    rs.getInt("Room_Number"),
                    rs.getInt("No_Of_days_Admitted"),
                    rs.getDate("Admission_Date"),
                    rs.getDate("Discharge_Date"),
                    rs.getString("Treatment"),
                    rs.getString("Room_Type"),
                    rs.getString("Want_Food")
                        
                    );
                }
            
        }
        return null;
    }

	public void deleteAllocationDetails(String id) throws SQLException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
	        String deleteAllocation = "DELETE FROM allocation WHERE ALLOCATION_ID = ?";

	        try (Connection conn = DBConnectionManager.getConnection()) {
	            conn.setAutoCommit(false);

	            try (PreparedStatement psAll = conn.prepareStatement(deleteAllocation);) {
	            	 psAll .setString(1, id);
	            	 psAll .executeUpdate();

	                conn.commit();
	            } catch (SQLException e) {
	                conn.rollback();
	                throw e;
	            }
	        }
	}

	public int getMaxRoomNumber()throws SQLException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		   int max = 0;
	        String query = "SELECT MAX(ROOM_NUMBER) AS max_id FROM allocation";

	        try (Connection conn = DBConnectionManager.getConnection();
	             PreparedStatement ps = conn.prepareStatement(query);
	             ResultSet rs = ps.executeQuery()) {
	        	if (rs.next()) {
	                max = rs.getInt("max_id");  // returns 0 if NULL
	            }
	        }
			return max;
		
	}
	}
		
	

