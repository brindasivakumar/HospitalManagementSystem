package com.util;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.sql.Date;

public class ApplicationUtil {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    public static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

        public static List<String> extractData(String inputString) {
        return Arrays.asList(inputString.split(":")); 
    }
        public static List<String> extractDataComma(String inputString) {
            return Arrays.asList(inputString.split(",")); 
        }


    /*public static Date convertStringToSQLDate(String dateStr) throws ParseException {
        java.util.Date utilDate = dateFormat.parse(dateStr);
        return new Date(utilDate.getTime());
    }*/
    public static Date convertStringToSQLDate(String dateStr) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = dateFormat.parse(dateStr);
        return new java.sql.Date(utilDate.getTime());
    }


    public static String convertDateToString(java.util.Date date) {
        return dateFormat.format(date);
    }

    public static java.util.Date convertSQLDateToUtilDate(Date sqlDate) {
        return new java.util.Date(sqlDate.getTime());
    }
    public static Time convertStringToSQLTime(String timeStr) throws ParseException {
        java.util.Date utilDate = timeFormat.parse(timeStr);
        return new Time(utilDate.getTime());
    }

   
  public static boolean validatePhoneNo(long phoneNo) {
	  String str=String.valueOf(phoneNo);
    return  str.matches("[789]\\d{9}");
  }
  public static boolean validateAge(int age) {
      return  age > 0;
  }

  public static boolean validateGender(String gender) {
      return gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("Other");
  }

  public static boolean validatePaymentMode(String paymentMode) {
      return paymentMode.equalsIgnoreCase("Cash") || paymentMode.equalsIgnoreCase("Card") || paymentMode.equalsIgnoreCase("Insurance");
  }  


}




