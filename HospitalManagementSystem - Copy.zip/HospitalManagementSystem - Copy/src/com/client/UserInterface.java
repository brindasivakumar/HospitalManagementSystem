package com.client;

import com.model.OutPatient;
import com.model.InPatient;
import com.model.Doctor;
import com.model.Allocation;
import com.service.OutPatientService;
import com.util.ApplicationUtil;
import com.service.InPatientService;
import com.service.AllocationService;
import com.service.DoctorService;
import com.exception.HospitalManagementException;

import java.util.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;

public class UserInterface {
    private static Scanner scanner = new Scanner(System.in);
    private static boolean running = true;

    public static void main(String[] args) throws SQLException, IOException, ParseException, ClassNotFoundException {
        while (running) {
            System.out.println("\n===== Hospital Management System =====");
            System.out.println("1. Inpatient");
            System.out.println("2. Outpatient");
            System.out.println("3. Doctor");
            System.out.println("4. Appointment");
            System.out.println("5. Allocation");
            System.out.println("6. Payment");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int option = Integer.parseInt(scanner.nextLine());

            switch (option) {
                case 1:
                    inpatientMenu();
                    break;
                case 2:
                    outpatientMenu();
                    break;
                case 3:
                    doctorMenu();
                    break;
                case 5:
                	 allocationMenu();
                	 break;
                case 7:
                    System.out.println("Exiting application. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Option not implemented yet or invalid. Try again.");
            }
        }
    }

    // Inpatient management menu
    private static void inpatientMenu() {
        boolean inpatientRunning = true;
        while (inpatientRunning) {
            System.out.println("\n===== InPatient Management =====");
            System.out.println("1. Add InPatients");
            System.out.println("2. Update InPatient Phone");
            System.out.println("3. Update InPatient Room Type");
            System.out.println("4. Update InPatient Food");
            System.out.println("5. Retrieve InPatient Details");
            System.out.println("6. Delete InPatient");
            System.out.println("7. Exit InPatient Management");
            System.out.print("Choose an option: ");
            String input = scanner.nextLine();

            switch (input) {
                case "1": addInPatients(); break;
                case "2": updatePhone1(); break;
                case "3": updateRoom(); break;
                case "4": updateFood(); break;
                case "5": retrieveInPatient(); break;
                case "6": deleteInPatient(); break;
                case "7":
                    inpatientRunning = false;
                    System.out.println("Exiting InPatient Management.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-7.");
            }
        }
    }

    // Outpatient management menu
    private static void outpatientMenu() {
        boolean outpatientRunning = true;
        while (outpatientRunning) {
            System.out.println("\n===== OutPatient Management =====");
            System.out.println("1. Add OutPatients");
            System.out.println("2. Update OutPatient Phone");
            System.out.println("3. Retrieve OutPatient Details");
            System.out.println("4. Delete OutPatient");
            System.out.println("5. Exit OutPatient Management");
            System.out.print("Choose an option: ");
            String input = scanner.nextLine();

            switch (input) {
                case "1": addOutPatients(); break;
                case "2": updatePhone(); break;
                case "3": retrieveOutPatient(); break;
                case "4": deleteOutPatient(); break;
                case "5":
                    outpatientRunning = false;
                    System.out.println("Exiting OutPatient Management.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-5.");
            }
        }
    }

    // Doctor management menu
    private static void doctorMenu() throws SQLException, IOException, ParseException, ClassNotFoundException {
        // DoctorService doctorService = new DoctorService();
        boolean doctorRunning = true;

        while (doctorRunning) {
            System.out.println("\n===== Doctor Management =====");
            System.out.println("1. Add Doctors");
            System.out.println("2. Update Doctor Fee");
            System.out.println("3. Update Doctor Available Date");
            System.out.println("4. Retrieve Doctor Details");
            System.out.println("5. Exit Doctor Management");
            System.out.print("Choose an option: ");
            String input = scanner.nextLine();

            switch (input) {
                case "1":
                    addDoctors();
                    break;
                case "2":
                    updateDoctorFee();
                    break;
                case "3":
                    updateDoctorAvailableDate();
                    break;
                case "4":
                    retrieveDoctorDetails();
                    break;
                case "5":
                    doctorRunning = false;
                    System.out.println("Exiting Doctor Management.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-6.");
            }
        }
    }
    
    // Allocation Menu
    private static void allocationMenu() throws ParseException {
    	boolean all=getInPatientId();
    	if(all) {
    		boolean check=checkAllocationExists();
    		if(!check) {
    		     boolean allocationRunning = true;
    			while (allocationRunning) {
    	            System.out.println("\n===== Allocation Management =====");
    	            System.out.println("1. Add Allocation Details");
    	            System.out.println("2. Retrieve Allocation Details");
    	            System.out.println("3. Delete Allocation");
    	            System.out.println("4. Exit InPatient Management");
    	            System.out.print("Choose an option: ");
    	            String input = scanner.nextLine();

    	            switch (input) {
    	                case "1": addAllocation(); break;
    	                case "2": retrieveAllocation(); break;
    	                case "3": deleteAllocation(); break;
    	                case "4":
    	                    allocationRunning = false;
    	                    System.out.println("Exiting Allocation Management.");
    	                    break;
    	                default:
    	                    System.out.println("Invalid choice. Please select 1-7.");
    	            }
    	        }
    			
    	}
    		else {
    			boolean allocationRunning = true;
    			while (allocationRunning) {
    	            System.out.println("\n===== Allocation Management =====");
    	            System.out.println("1. Retrieve Allocation Details");
    	            System.out.println("2. Delete Allocation");
    	            System.out.println("3. Exit InPatient Management");
    	            System.out.print("Choose an option: ");
    	            String input = scanner.nextLine();

    	            switch (input) {
    	                case "1": retrieveAllocation(); break;
    	                case "2": deleteAllocation(); break;
    	                case "3":
    	                    allocationRunning = false;
    	                    System.out.println("Exiting Allocation Management.");
    	                    break;
    	                default:
    	                    System.out.println("Invalid choice. Please select 1-7.");
    	            }
    	        }
    			
    		}
    	}
    	else {
    		System.out.println("Kindly register as an InPatient");
    		
    	}
        
    	
    }
    

    // --------------------- InPatient methods ---------------------

   

	private static void addInPatients() {
        List<String> records = new ArrayList<>();

        System.out.println("Enter inpatient details (Format:name:phone:age:gender:medicalHistory:specialist:medicineFee:patientType:admissionFee:treatment:roomType:wantFood)");
        String record = scanner.nextLine();
        records.add(record);

        try {
            List<InPatient> inPatients = InPatientService.buildInPatientList(records);
            InPatientService.addInPatientList(inPatients);
            System.out.println("InPatients added successfully.");
        } catch (HospitalManagementException | SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error adding inpatients: " + e.getMessage());
        }
    }

    private static void updatePhone1() {
        System.out.print("Enter patient ID to update phone: ");
        String id = scanner.nextLine();
        System.out.print("Enter new phone number: ");
        String newPhone = scanner.nextLine();

        try {
            InPatientService.updateInPatientPhone(id, newPhone);
            System.out.println("Phone number updated successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error updating phone: " + e.getMessage());
        }
    }

    private static void updateRoom() {
        System.out.print("Enter patient ID to update room type: ");
        String id = scanner.nextLine();
        System.out.print("Enter new room type: ");
        String newRoom = scanner.nextLine();

        try {
            InPatientService.updateInPatientRoom(id, newRoom);
            System.out.println("Room Type updated successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error updating room type: " + e.getMessage());
        }
    }

    private static void updateFood() {
        System.out.print("Enter patient ID to update food: ");
        String id = scanner.nextLine();
        System.out.print("Enter new food: ");
        String newFood = scanner.nextLine();

        try {
            InPatientService.updateInPatientFood(id, newFood);
            System.out.println("Food updated successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error updating food: " + e.getMessage());
        }
    }

    private static void retrieveInPatient() {
        System.out.print("Enter patient ID to retrieve details: ");
        String id = scanner.nextLine();

        try {
            InPatient patient = InPatientService.retrieveInPatient(id);
            if (patient != null) {
                System.out.println("InPatient Details:");
                System.out.println(patient);
            } else {
                System.out.println("No inpatient found with ID: " + id);
            }
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error retrieving inpatient: " + e.getMessage());
        }
    }

    private static void deleteInPatient() {
        System.out.print("Enter patient ID to delete: ");
        String id = scanner.nextLine();

        try {
            InPatientService.deleteInPatient(id);
            System.out.println("InPatient deleted successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error deleting inpatient: " + e.getMessage());
        }
    }

    // --------------------- OutPatient methods ---------------------

    private static void addOutPatients() {
        System.out.print("Enter number of outpatients to add: ");
        int n = Integer.parseInt(scanner.nextLine());
        List<String> records = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.println("Enter outpatient details (Format: Name:PhoneNo:age:gender:medicalHistory:specialist:medicineFee:patientType:registrationFee):");
            String record = scanner.nextLine();
            records.add(record);
        }

        try {
            List<OutPatient> outPatients = OutPatientService.buildOutPatientList(records);
            OutPatientService.addOutPatientList(outPatients);
            System.out.println("OutPatients added successfully.");
        } catch (HospitalManagementException | SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error adding outpatients: " + e.getMessage());
        }
    }

    private static void updatePhone() {
        System.out.print("Enter patient ID to update phone: ");
        String id = scanner.nextLine();
        System.out.print("Enter new phone number: ");
        String newPhone = scanner.nextLine();

        try {
            OutPatientService.updateOutPatientPhone(id, newPhone);
            System.out.println("Phone number updated successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error updating phone: " + e.getMessage());
        }
    }

    private static void retrieveOutPatient() {
        System.out.print("Enter patient ID to retrieve details: ");
        String id = scanner.nextLine();

        try {
            OutPatient patient = OutPatientService.retrieveOutPatient(id);
            if (patient != null) {
                System.out.println("OutPatient Details:");
                System.out.println(patient);
            } else {
                System.out.println("No outpatient found with ID: " + id);
            }
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error retrieving outpatient: " + e.getMessage());
        }
    }

    private static void deleteOutPatient() {
        System.out.print("Enter patient ID to delete: ");
        String id = scanner.nextLine();

        try {
            OutPatientService.deleteOutPatient(id);
            System.out.println("OutPatient deleted successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error deleting outpatient: " + e.getMessage());
        }
    }

    

    private static void addDoctors() throws ClassNotFoundException, ParseException {
       
            List<String> records = new ArrayList<>();

            System.out.println("Enter doctor details in this format:");
            System.out.println("Name,Fees,Specialization,AvailableDate(yyyy-MM-dd),AvailableTime(HH:mm:ss)");
            String record=scanner.nextLine();
            records.add(record);
            
            
            try {
                
                List<Doctor> doctors = DoctorService.buildDoctorList(records);
                DoctorService.addDoctorList(doctors);

                System.out.println("Doctors added successfully.");

            } catch (Exception e) {
                System.out.println("An error occurred while adding doctors: " + e.getMessage());
                e.printStackTrace();
            }
        }
     

      
   
    private static void updateDoctorFee() throws SQLException, IOException {
        
        System.out.print("Enter Doctor ID to update fee: ");
        String id = scanner.nextLine();

        System.out.print("Enter new fee: ");
        double newFee = scanner.nextDouble();

        try {
            DoctorService.updateDoctorFee(id, newFee);
            System.out.println("Fee updated successfully.");
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error updating Fee: " + e.getMessage());
        }
    }

    private static void updateDoctorAvailableDate() throws ParseException, SQLException {
    	  System.out.print("Enter Doctor ID to update available date: ");
          String id = scanner.nextLine();

          System.out.print("Enter new available date (yyyy-MM-dd): ");
          String dateStr = scanner.nextLine();

       
              Date newDate = ApplicationUtil.convertStringToSQLDate(dateStr);
              try {
                  DoctorService.updateDoctorAvailableDate(id, newDate);
                  System.out.println("Date updated successfully.");
              } catch (SQLException | ClassNotFoundException | IOException e) {
                  System.out.println("Error updating Date: " + e.getMessage());
              }
          
      }
    private static void retrieveDoctorDetails() throws ClassNotFoundException, SQLException, IOException {
       
        System.out.print("Enter Doctor ID to retrieve details: ");
        String id = scanner.nextLine();

        Doctor doctor = DoctorService.retrieveDoctorDetails(id);
        if (doctor != null) {
            System.out.println("Doctor Details:");
            System.out.println(doctor);
        } else {
            System.out.println("Doctor not found.");
        }
    }
    
    //-----------------------Allocation Methods-----------------------
    private static boolean getInPatientId() {
        System.out.println("Enter patient name");
        String name = scanner.nextLine();
        System.out.println("Enter patient phone number");
        long phone = scanner.nextLong();
        scanner.nextLine(); 
        try {
            String allocation = AllocationService.getInPatientId(name, phone);
            if (allocation != null) {
                System.out.println("Your Id is:");
                System.out.println(allocation);
                return true;
            } else {
            	System.out.println("No inpatient found with name: " + name + " and phone number " + phone);
                return false;
            }
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error retrieving inpatient: " + e.getMessage());
            return false;
        }
    }
    private static boolean checkAllocationExists() {
        System.out.println("Enter InPatient ID to check:");
        String id = scanner.nextLine();

        try {
            boolean exists = AllocationService.checkPatientId(id);
            if (exists) {
                System.out.println("InPatient with ID " + id + " exists in the system.");
                return true;
            } else {
                return false;
            }
        } catch (SQLException | IOException | ClassNotFoundException e) {
            System.out.println("Error while checking OutPatient ID: " + e.getMessage());
            return false;
        }
        }
    private static void addAllocation() throws ParseException {
        List<String> records = new ArrayList<>();

        System.out.println("Enter allocation details (Format:patientid:no)fDaysAdmitted: admission Date:treatment:roomType:wantFood)");
        String record = scanner.nextLine();
        records.add(record);

        try {
            List<Allocation> allocation = AllocationService.buildAllocationList(records);
            AllocationService.addAllocationList(allocation);
            System.out.println("Allocation Details added successfully.");
        } catch (HospitalManagementException | SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error adding allocation: " + e.getMessage());
        }
    }
    private static void deleteAllocation() {
		// TODO Auto-generated method stub
    	 System.out.print("Enter allocation ID to delete: ");
         String id = scanner.nextLine();

         try {
        	 AllocationService.deleteAllocation(id);
             System.out.println("Allocation deleted successfully.");
         } catch (SQLException | ClassNotFoundException | IOException e) {
             System.out.println("Error deleting allocation: " + e.getMessage());
         }
    	
		
	}

	private static void retrieveAllocation() {
		// TODO Auto-generated method stub
		System.out.print("Enter Allocation ID to retrieve details: ");
        String id = scanner.nextLine();

        try {
            Allocation allocation = AllocationService.retrieveAllocation(id);
            if ( allocation != null) {
                System.out.println("Allocation Details:");
                System.out.println(allocation);
            } else {
                System.out.println("No allocation found with ID: " + id);
            }
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.out.println("Error retrieving allocation: " + e.getMessage());
        }
		
	}
    
    }


    

