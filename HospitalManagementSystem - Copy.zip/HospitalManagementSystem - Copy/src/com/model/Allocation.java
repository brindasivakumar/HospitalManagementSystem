package com.model;
import java.util.Date;

public class Allocation {
	private String allocationId;
	private String patientId;
	private int roomNumber;
	private int noOfdaysAdmitted;
	private Date admissionDate;
	private Date dischargeDate;
	private String treatment;
	private String roomType;
	private String wantFood;
	
	public Allocation(String allocationId, String patientId, int roomNumber, int noOfdaysAdmitted, Date admissionDate,
			Date dischargeDate, String treatment, String roomType, String wantFood) {
//		super();
		this.allocationId = allocationId;
		this.patientId = patientId;
		this.roomNumber = roomNumber;
		this.noOfdaysAdmitted = noOfdaysAdmitted;
		this.admissionDate = admissionDate;
		this.dischargeDate = dischargeDate;
		this.treatment = treatment;
		this.roomType = roomType;
		this.wantFood = wantFood;
	}
	public String getAllocationId() {
		return allocationId;
	}
	public void setAllocationID(String allocationId) {
		this.allocationId = allocationId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public int getNoOfdaysAdmitted() {
		return noOfdaysAdmitted;
	}
	public void setNoOfdaysAdmitted(int noOfdaysAdmitted) {
		this.noOfdaysAdmitted = noOfdaysAdmitted;
	}
	public Date getAdmissionDate() {
		return admissionDate;
	}
	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}
	public Date getDischargeDate() {
		return dischargeDate;
	}
	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}
	public String getTreatment() {
		return treatment;
	}
	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public String getWantFood() {
		return wantFood;
	}
	public void setWantFood(String wantFood) {
		this.wantFood = wantFood;
	}
	@Override
	public String toString() {
	    return 
	           "Allocation ID      : " + this.getAllocationId() + "\n" +
	           "Patient ID         : " + this.getPatientId() + "\n" +
	           "Room Number        : " + this.getRoomNumber() + "\n" +
	           "No. of Days        : " + this.getNoOfdaysAdmitted() + "\n" +
	           "Admission Date     : " + this.getAdmissionDate() + "\n" +
	           "Discharge Date     : " + this.getDischargeDate() + "\n" +
	           "Treatment          : " + this.getTreatment() + "\n" +
	           "Room Type          : " + this.getRoomType() + "\n" +
	           "Want Food          : " + this.getWantFood() + "\n";
	}


	
}