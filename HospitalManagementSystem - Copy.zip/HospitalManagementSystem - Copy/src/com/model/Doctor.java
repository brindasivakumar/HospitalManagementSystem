package com.model;
import java.sql.Time;
import java.util.Date;
public class Doctor  {
	
	private String doctorId;
	private String doctorName;
	private double doctorFees;
	private String specialization;
	private Date availableDate;
	private Time availableTime;
	public Doctor(String doctorId, String doctorName, double doctorFees, String specialization, Date availableDate,
			Time availableTime) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFees = doctorFees;
		this.specialization = specialization;
		this.availableDate = availableDate;
		this.availableTime = availableTime;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public double getDoctorFees() {
		return doctorFees;
	}
	public void setDoctorFees(double doctorFees) {
		this.doctorFees = doctorFees;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public Date getAvailableDate() {
		return availableDate;
	}
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}
	public Time getAvailableTime() {
		return availableTime;
	}
	public void setAvailableTime(Time availableTime) {
		this.availableTime = availableTime;
	}
	@Override
	public String toString() {
	    return 
	           "Doctor ID          : " + this.getDoctorId() + "\n" +
	           "Doctor Name        : " + this.getDoctorName() + "\n" +
	           "Doctor Fees        : " + this.getDoctorFees() + "\n" +
	           "Specialization     : " + this.getSpecialization() + "\n" +
	           "Available Date     : " + this.getAvailableDate() + "\n" +
	           "Available Time     : " + this.getAvailableTime() + "\n";
	}


	

}
