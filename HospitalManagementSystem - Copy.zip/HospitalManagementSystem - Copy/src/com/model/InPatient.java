package com.model;

public class InPatient extends Patient{

private double admissionFees;
private String treatment;
private String roomType;
private String wantFood;
public InPatient(String patientId, String patientName, long phoneNumber, int age, String gender,
		String medicalHistory, String prefferedSpecialist, double medicineFee, String patientType, double admissionFees, String treatment, String roomType, String wantFood) {
	super(patientId, patientName, phoneNumber, age, gender, medicalHistory, prefferedSpecialist, medicineFee,
			patientType);
	this.admissionFees = admissionFees;
	this.treatment = treatment;
	this.roomType = roomType;
	this.wantFood = wantFood;
}
public String getTreatment() {
	return treatment;
}
public void setTreatment(String treatment) {
	this.treatment = treatment;
}
public String getRoomType() {
	return roomType;
}
public void setRoomType(String roomType) {
	this.roomType = roomType;
}
public String getWantFood() {
	return wantFood;
}
public void setWantType(String wantFood) {
	this.wantFood = wantFood;
}
public double getAdmissionFees() {
	return admissionFees;
}
public void setAdmissionFees(double admissionFees) {
	this.admissionFees = admissionFees;
}
@Override
public String toString() {
    return 
           "Patient ID: " + this.getPatientId() + "\n" +
           "Name: " + this.getPatientName() + "\n" +
           "Phone: " + this.getPhoneNumber() + "\n" +
           "Age: " + this.getAge() + "\n" +
           "Gender: " + this.getGender() + "\n" +
           "Medical History: " + this.getMedicalHistory() + "\n" +
           "Specialist: " + this.getPrefferedSpecialist() + "\n" +
           "Medicine Fee: " + this.getMedicineFee() + "\n" +
           "Patient Type: " + this.getPatientType() + "\n" +
           "Admission Fee: " + this.getAdmissionFees() +"\n"+
           "Room Type: " +this.getRoomType() +"\n"+
           "Treatment : "+this.getTreatment() +"\n"+
           "Food :" +this.getWantFood() +"\n";
}
}
