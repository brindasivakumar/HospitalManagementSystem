
package com.model;

public class OutPatient extends Patient {
	private double registrationFee;
	
	public OutPatient(String patientId, String patientName, long phoneNumber, int age, String gender,
			String medicalHistory, String prefferedSpecialist, double medicineFee, String patientType,
			double registrationFee) {
		super(patientId, patientName, phoneNumber, age, gender, medicalHistory, prefferedSpecialist, medicineFee,
				patientType);
		this.registrationFee = registrationFee;
	}	
	public double getRegistrationFee() {
		return registrationFee;
	}
	public void setRegistrationFee(double registrationFee) {
		this.registrationFee = registrationFee;
	}
	 @Override
	    public String toString() {
	        return "OutPatient Details:\n" +
	               "Patient ID: " + this.getPatientId() + "\n" +
	               "Name: " + this.getPatientName() + "\n" +
	               "Phone: " + this.getPhoneNumber() + "\n" +
	               "Age: " + this.getAge() + "\n" +
	               "Gender: " + this.getGender() + "\n" +
	               "Medical History: " + this.getMedicalHistory() + "\n" +
	               "Specialist: " + this.getPrefferedSpecialist() + "\n" +
	               "Medicine Fee: " + this.getMedicineFee() + "\n" +
	               "Patient Type: " + this.getPatientType() + "\n" +
	               "Registration Fee: " + this.getRegistrationFee();
	    }

	

}
