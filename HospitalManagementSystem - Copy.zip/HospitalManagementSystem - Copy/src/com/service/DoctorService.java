package com.service;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.sql.Date;
import java.util.*;

import com.exception.HospitalManagementException;
import com.management.DoctorManagement;
import com.model.Doctor;

import com.util.ApplicationUtil;

public class DoctorService {

    private static int count = 0;
    private static final String PREFIX = "DOC";
    private static final DoctorManagement obj1 = new DoctorManagement();
    private static final List<Doctor> doctorList = new ArrayList<>();

    // Generate ID
    public static String generateId() throws SQLException, ClassNotFoundException, IOException {
        int maxId = obj1.getMaxDoctorIdNumber(); 
        count = maxId;
        return PREFIX + (++count);
    }

    // Build Doctor List
    public static List<Doctor> buildDoctorList(List<String> records) throws HospitalManagementException, ClassNotFoundException, SQLException, IOException, ParseException {
        List<Doctor> list = new ArrayList<>();

        for (String rec : records) {
            List<String> fields = ApplicationUtil.extractDataComma(rec);
            String name = fields.get(0);
            double fee = Double.parseDouble(fields.get(1));
            String specialization = fields.get(2);
            Date availableDate = ApplicationUtil.convertStringToSQLDate(fields.get(3));
            Time availableTime = ApplicationUtil.convertStringToSQLTime(fields.get(4));

            String id = generateId();

            Doctor doctor = new Doctor(id, name, fee, specialization, availableDate, availableTime);
            list.add(doctor);
            doctorList.add(doctor);  // Add to static list
        }

        return list;
    }

    // Add doctor
    public static void addDoctorList(List<Doctor> list) throws SQLException, ClassNotFoundException, IOException {
        obj1.insertDoctorList(list);
    }

    // Update doctor fee
    /*public static boolean updateDoctorFee(String id, String newFee) {
        for (Doctor doc : doctorList) {
            if (doc.getDoctorId().equalsIgnoreCase(id)) {
                doc.setDoctorFees(Double.parseDouble(newFee));
                return true;
            }
        }
        return false;
    }*/
    public static void updateDoctorFee(String id, double newFee) throws SQLException, ClassNotFoundException, IOException {
        double fee = newFee;
        obj1.updateDoctorFee(id, fee);
    }
    
    // Update available date
    /*public static boolean updateDoctorAvailableDate(String doctorId, Date newDate) {
        for (Doctor doctor : doctorList) {
            if (doctor.getDoctorId().equalsIgnoreCase(doctorId)) {
                doctor.setAvailableDate(newDate);
                return true;
            }
        }
        return false;
    }*/
    public static void updateDoctorAvailableDate(String id, Date newDate) throws SQLException, ClassNotFoundException, IOException {
        Date date = newDate;
        obj1.updateDoctorAvailableDate(id, date);
    }

    
    public static Doctor retrieveDoctorDetails(String doctorId) throws ClassNotFoundException, SQLException, IOException {
    	
		return obj1.retrieveDoctorDetails(doctorId);
    }
    

   
   
    
   
}