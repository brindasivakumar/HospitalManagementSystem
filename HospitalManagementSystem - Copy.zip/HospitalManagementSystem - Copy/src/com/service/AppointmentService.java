package com.service;

public class AppointmentService {

}
