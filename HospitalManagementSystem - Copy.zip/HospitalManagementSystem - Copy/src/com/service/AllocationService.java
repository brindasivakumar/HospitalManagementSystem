package com.service;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.time.LocalDate;
// import java.text.ParseException;
import java.sql.Date;
import java.util.*;

import com.exception.HospitalManagementException;
import com.management.AllocationManagement;
import com.management.DoctorManagement;
import com.model.Allocation;
import com.model.Doctor;
import com.util.ApplicationUtil;
public class AllocationService {
	private static int count = 0;
	private static int count1 = 0;
    private static final String PREFIX = "ALL";
     // private static final String PREFIX1 = "ROOM";
    private static final AllocationManagement obj1 = new AllocationManagement();
   // private static final List<Allocation> allocationList = new ArrayList<>();

    // Generate ID
    public static String generateId() throws SQLException, ClassNotFoundException, IOException {
        int maxId = obj1.getMaxAllocationIdNumber(); 
        count = maxId;
        return PREFIX + (++count);
    }	
     public static String getInPatientId(String name,long phone) throws SQLException, ClassNotFoundException, IOException {
    	 ApplicationUtil.validatePhoneNo(phone);
    	 return obj1.getInPatientId(name,phone);
     }
     //Generate Room Number
     public static int generateRoom() throws SQLException, ClassNotFoundException, IOException {
         int maxId = obj1.getMaxRoomNumber(); 
         count1 = maxId;
         return ++count1;
     }
    
	public static boolean checkPatientId(String id)throws SQLException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		 return obj1.checkIdExists(id);
	}
	  public static List<Allocation> buildAllocationList(List<String> records) throws HospitalManagementException, ClassNotFoundException, SQLException, IOException, ParseException {
	        List<Allocation> list1 = new ArrayList<>();

	        for (String rec : records) {
	            List<String> fields1 = ApplicationUtil.extractData(rec);

	            String pid = fields1.get(0);
	            int noOfDays = Integer.parseInt(fields1.get(1));
	            Date adDate = ApplicationUtil.convertStringToSQLDate(fields1.get(2));
	            String treatment = fields1.get(3);
	            String roomType = fields1.get(4);
	            String wantFood = fields1.get(5);
	            LocalDate dischargeLocalDate = adDate.toLocalDate().plusDays(noOfDays);
	            Date disDate = Date.valueOf(dischargeLocalDate);
	            String id = generateId();
	            int roomNo = generateRoom();
	           Allocation obj1 = new Allocation(id,pid,roomNo,noOfDays,adDate, disDate, treatment, roomType, wantFood);
	            list1.add(obj1);
	        }
	        return list1;
	    }
	public static void addAllocationList(List<Allocation> list1) throws SQLException, ClassNotFoundException, IOException{
		// TODO Auto-generated method stub
		obj1.insertAllocationList(list1);
		
	}
	public static Allocation retrieveAllocation(String id)throws SQLException, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		  return obj1.retrieveAllocationDetails(id);
	}
	public static void deleteAllocation(String id) throws SQLException, ClassNotFoundException, IOException {
        obj1.deleteAllocationDetails(id);
    }
	
}
