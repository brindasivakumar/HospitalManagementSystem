package com.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import com.exception.HospitalManagementException;
import com.management.OutPatientManagement;
import com.model.OutPatient;
import com.util.ApplicationUtil;

public class OutPatientService {

    private static int count = 0;
    private static final String PREFIX = "OUTP";
  static OutPatientManagement obj1 = new OutPatientManagement();

    // Generate ID
  public static String generateId() throws SQLException, ClassNotFoundException, IOException {
      int maxId = obj1.getMaxOutPatientIdNumber(); // Method to fetch max existing number from DB
      count = maxId;
      return PREFIX + (++count);
  }

    // Build OutPatient List from raw input strings
    public static List<OutPatient> buildOutPatientList(List<String> records) throws HospitalManagementException, ClassNotFoundException, SQLException, IOException {
        List<OutPatient> list = new ArrayList<>();

        for (String rec : records) {
            List<String> fields = ApplicationUtil.extractData(rec);

            String name = fields.get(0);
            long phone = Long.parseLong(fields.get(1));
            int age = Integer.parseInt(fields.get(2));
            String gender = fields.get(3);
            String medicalHistory = fields.get(4);
            String specialist = fields.get(5);
            double medFee = Double.parseDouble(fields.get(6));
            String type = fields.get(7);
            double regFee = Double.parseDouble(fields.get(8));

            if(!ApplicationUtil.validatePhoneNo(phone)) {
            	System.out.println("Invalid Phone number");
            	continue;
            }
           if(!ApplicationUtil.validateAge(age)) {
        	  System.out.println("Invalid Age");
        	  continue;
           }
           
           if(!ApplicationUtil.validateGender(gender)) {
        	 System.out.println("Invalid Gender");
        	 continue;
           }

            String id = generateId();

            OutPatient obj = new OutPatient(id, name, phone, age, gender, medicalHistory, specialist, medFee, type, regFee);
            list.add(obj);
        }
        return list;
    }

    // Add OutPatient records using management class
    public static void addOutPatientList(List<OutPatient> list) throws SQLException, ClassNotFoundException, IOException {
        obj1.insertOutPatientList(list);
    }

    // Update phone number using management class
    public static void updateOutPatientPhone(String id, String newPhone) throws SQLException, ClassNotFoundException, IOException {
        long phone = Long.parseLong(newPhone);
        ApplicationUtil.validatePhoneNo(phone);
        obj1.updateOutPatientPhoneNumber(id, phone);
    } 
     

    // Retrieve OutPatient using management class
    public static OutPatient retrieveOutPatient(String id) throws SQLException, ClassNotFoundException, IOException {
        return obj1.retrieveOutPatientList(id);
    }

    // Delete OutPatient using management class
    public static void deleteOutPatient(String id) throws SQLException, ClassNotFoundException, IOException {
        obj1.deleteOutpatientDetailsFromDB(id);
    }
}