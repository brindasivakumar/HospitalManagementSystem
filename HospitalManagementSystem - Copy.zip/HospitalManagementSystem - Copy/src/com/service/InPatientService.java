package com.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import com.exception.HospitalManagementException;
import com.management.InPatientManagement;
import com.model.InPatient;
import com.util.ApplicationUtil;

public class InPatientService {

    private static int count = 0;
    private static final String PREFIX = "INP";
  static InPatientManagement obj1 = new InPatientManagement();

    // Generate ID
  public static String generateId() throws SQLException, ClassNotFoundException, IOException {
      int maxId = obj1.getMaxInPatientIdNumber(); // Method to fetch max existing number from DB
      count = maxId;
      return PREFIX + (++count);
  }

    // Build InPatient List from raw input strings
    public static List<InPatient> buildInPatientList(List<String> records) throws HospitalManagementException, ClassNotFoundException, SQLException, IOException {
        List<InPatient> list1 = new ArrayList<>();

        for (String rec : records) {
            List<String> fields1 = ApplicationUtil.extractData(rec);

            String name = fields1.get(0);
            long phone = Long.parseLong(fields1.get(1));
            int age = Integer.parseInt(fields1.get(2));
            String gender = fields1.get(3);
            String medicalHistory = fields1.get(4);
            String specialist = fields1.get(5);
            double medFee = Double.parseDouble(fields1.get(6));
            String type = fields1.get(7);
            double admFee = Double.parseDouble(fields1.get(8));
            String treatment = fields1.get(9);
            String roomType = fields1.get(10);
            String wantFood = fields1.get(11);

            if(!ApplicationUtil.validatePhoneNo(phone)) {
            	System.out.println("Invalid Phone number");
            	continue;
            }
           if(!ApplicationUtil.validateAge(age)) {
        	  System.out.println("Invalid Age");
        	  continue;
           }
           
           if(!ApplicationUtil.validateGender(gender)) {
        	 System.out.println("Invalid Gender");
        	 continue;
           }

            String id = generateId();

           InPatient obj1 = new InPatient(id, name, phone, age, gender, medicalHistory, specialist, medFee, type, admFee, treatment, roomType, wantFood);
            list1.add(obj1);
        }
        return list1;
    }

    // Add InPatient records using management class
    public static void addInPatientList(List<InPatient> list) throws SQLException, ClassNotFoundException, IOException {
        obj1.insertInPatientList(list);
    }

    // Update phone number using management class
    public static void updateInPatientPhone(String id, String newPhone) throws SQLException, ClassNotFoundException, IOException {
        long phone = Long.parseLong(newPhone);
        ApplicationUtil.validatePhoneNo(phone);
        obj1.updateInPatientPhoneNumber(id, phone);
    }

    public static void updateInPatientRoom(String id, String newRoom) throws SQLException, ClassNotFoundException, IOException {
        String room = newRoom;
        obj1.updateInPatientRoomType(id, room);
    }

    public static void updateInPatientFood(String id, String newFood) throws SQLException, ClassNotFoundException, IOException {
        String food = newFood;
        obj1.updateInPatientFood(id, food);
    }
    // Retrieve InPatient using management class
    public static InPatient retrieveInPatient(String id) throws SQLException, ClassNotFoundException, IOException {
        return obj1.retrieveInPatientList(id);
    }

    // Delete InPatient using management class
    public static void deleteInPatient(String id) throws SQLException, ClassNotFoundException, IOException {
        obj1.deleteInpatientDetailsFromDB(id);
    }
}
